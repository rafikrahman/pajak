<div>
    <?php echo e($this->form); ?>

</div>
<?php /**PATH E:\XAMPP\htdocs\pajak\resources\views\livewire\form.blade.php ENDPATH**/ ?>