<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Perusahaanpap extends Model
{
    use HasFactory;

    protected $fillable = [
        'iden',
        'noreg',
        'name',
        'uptd_id',
        'alamat',
        'province_id',
        'regency_id',
        'district_id',
        'email',
        'website',
        'namekontak',
        'ponsel',
        'emailkontak',
        'koreksatu_id',
        'status'
    ];
}
