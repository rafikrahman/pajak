<?php

namespace App\Filament\Resources\KonsumenResource\Pages;

use App\Filament\Resources\KonsumenResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateKonsumen extends CreateRecord
{
    protected static string $resource = KonsumenResource::class;
}
