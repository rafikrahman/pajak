<?php

namespace App\Filament\Resources\PerusahaanResource\Pages;

use App\Filament\Resources\PerusahaanResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePerusahaan extends CreateRecord
{
    protected static string $resource = PerusahaanResource::class;
}
