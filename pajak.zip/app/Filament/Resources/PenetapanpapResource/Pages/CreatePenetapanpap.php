<?php

namespace App\Filament\Resources\PenetapanpapResource\Pages;

use App\Filament\Resources\PenetapanpapResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePenetapanpap extends CreateRecord
{
    protected static string $resource = PenetapanpapResource::class;
}
