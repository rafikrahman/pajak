<?php

namespace App\Filament\Resources\KorekduaResource\Pages;

use App\Filament\Resources\KorekduaResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateKorekdua extends CreateRecord
{
    protected static string $resource = KorekduaResource::class;
}
