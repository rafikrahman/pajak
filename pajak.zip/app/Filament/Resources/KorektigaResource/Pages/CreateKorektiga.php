<?php

namespace App\Filament\Resources\KorektigaResource\Pages;

use App\Filament\Resources\KorektigaResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateKorektiga extends CreateRecord
{
    protected static string $resource = KorektigaResource::class;
}
