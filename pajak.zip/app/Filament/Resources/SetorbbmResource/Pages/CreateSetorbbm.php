<?php

namespace App\Filament\Resources\SetorbbmResource\Pages;

use App\Filament\Resources\SetorbbmResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSetorbbm extends CreateRecord
{
    protected static string $resource = SetorbbmResource::class;
}
