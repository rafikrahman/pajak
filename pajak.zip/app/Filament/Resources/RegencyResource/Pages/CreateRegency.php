<?php

namespace App\Filament\Resources\RegencyResource\Pages;

use App\Filament\Resources\RegencyResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateRegency extends CreateRecord
{
    protected static string $resource = RegencyResource::class;
}
