<?php

namespace App\Filament\Resources\UptdResource\Pages;

use App\Filament\Resources\UptdResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateUptd extends CreateRecord
{
    protected static string $resource = UptdResource::class;
}
