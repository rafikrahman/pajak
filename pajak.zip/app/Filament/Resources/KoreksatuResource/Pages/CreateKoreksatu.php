<?php

namespace App\Filament\Resources\KoreksatuResource\Pages;

use App\Filament\Resources\KoreksatuResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateKoreksatu extends CreateRecord
{
    protected static string $resource = KoreksatuResource::class;
}
