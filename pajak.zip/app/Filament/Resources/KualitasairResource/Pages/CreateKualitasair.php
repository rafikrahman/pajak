<?php

namespace App\Filament\Resources\KualitasairResource\Pages;

use App\Filament\Resources\KualitasairResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateKualitasair extends CreateRecord
{
    protected static string $resource = KualitasairResource::class;
}
