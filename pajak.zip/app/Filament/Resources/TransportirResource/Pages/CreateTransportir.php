<?php

namespace App\Filament\Resources\TransportirResource\Pages;

use App\Filament\Resources\TransportirResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateTransportir extends CreateRecord
{
    protected static string $resource = TransportirResource::class;
}
